package battlecode.server;

public enum GameState {
    RUNNING,
    DONE
}
